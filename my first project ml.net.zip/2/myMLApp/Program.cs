﻿using MyMLApp;

while (true)
{
	Console.WriteLine("\nenter your sentence: ");

	//add input data
	var data = new SentimentModel.ModelInput()
	{
		//Col0 = "this restaurant is wonderful.";
		Col0 = Console.ReadLine()
	};


	//load model + predict output 
	var result = SentimentModel.Predict(data);



	//predict --> 1 ?? positive : 0 ---> negative
	var sentiment = result.Prediction == 1 ? "positive" : "negative";


	Console.WriteLine($"\nText: {data.Col0}\nSentiment: {sentiment}");
	Console.WriteLine("\n******************************\n");
}